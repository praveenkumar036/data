package org.training.scala.traitsexample.examples1

/**
 * Created by hduser on 19/7/16.
 */

trait Logger {
  def log(msg: String)
  def test = println("Hello")
}