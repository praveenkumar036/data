package org.training.scala.companionobjects

/**
 * Created by Arjun.
  * Companion object accessing its representative class's private information
 */

class Person(val name: String, private  val superHeroName: String)

object  Person {

  def tellMeTheSecret(x: Person) = x.superHeroName

}
object CompanionExample2 {
  def main(args: Array[String]) {

    val peter = new Person("Peter Parker", "SpiderMan")

    println(Person.tellMeTheSecret(peter))
  }

}
