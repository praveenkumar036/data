package org.training.scala.read

/**
 * Created by hduser on 16/7/16.
 */
object ReadUsing {

  def using[A <: { def close(): Unit }, B](resource: A)(f: A => B): B =
    try {
      f(resource)
    } finally {
      resource.close()
    }

  def main(args: Array[String]) {

    val lines = using(scala.io.Source.fromFile(args(0)))(_.getLines())
    lines.foreach(println)
  }
}
