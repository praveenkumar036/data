section -
-------
The <section> tag defines in a document , such as chapters , headers , footers , or any other section of document.

Example:

 <section>
  <h1>WWF</h1>
  <p>The World Wide Fund for Nature (WWF) is....</p>
 </section> 

header-
------

The <header> element represents a container for introductory content or a set of navigational links.

A <header> element typically contains:

. one or more heading elements (<h1> - <h6>)
. logo or icon
. authorship information

<!DOCTYPE html>
<html>
<body>

<article>
  <header>
    <h1>Most important heading here</h1>
    <h3>Less important heading here</h3>
    <p>Some additional information here.</p>
  </header>
  <p>Lorem Ipsum dolor set amet....</p>
</article>

</body>
</html>


label - 
----- 

The <label> tag defines a label for an <input> element.
The <label> element does not render as anything special for the user. However , it provides a usability 
improvemnet for mouse users , becuase if the user clicks on the text within the <lable> element , it toggles the control.
The for attribute of the <label> tag should be equal to the 'id' attributes of the related element to bind them together.


 <form action="/action_page.php">
  <label for="male">Male</label>
  <input type="radio" name="gender" id="male" value="male"><br>
  <label for="female">Female</label>
  <input type="radio" name="gender" id="female" value="female"><br>
  <label for="other">Other</label>
  <input type="radio" name="gender" id="other" value="other"><br><br>
  <input type="submit" value="Submit">
</form> 

Note : A label element can be bound to an element either by using "for" attribute , or placing the element inside the <label> elemnt

<html>
<body>

<p>Click on one of the text labels to toggle the related control:</p>

<form action="/action_page.php">
  <label>Male<input type="radio" name="gender"></label>
 <br>
  <label for="female">Female</label>
  <input type="radio" name="gender" id="female" value="female"><br>
  <label for="other">Other</label>
  <input type="radio" name="gender" id="other" value="other"><br><br>
  <input type="submit" value="Submit">
</form>

</body>
</html>



'class' -
------

The HTML class attributes makes it possible to define equals styles for elements with the same class name.

Here we have three <div> elements that point to the same class name:

<html>
<head>
<style>
 div.cities {
    background-color: black;
    color: white;
    margin: 20px 0 20px 0;
    padding: 20px;
} 
</style>
</head>
<body>

<div class="cities">
<h2>London</h2>
<p>London is the capital of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
</div>

<div class="cities">
<h2>Paris</h2>
<p>Paris is the capital and most populous city of France.</p>
</div>

<div class="cities">
<h2>Tokyo</h2>
<p>Tokyo is the capital of Japan, the center of the Greater Tokyo Area,
and the most populous metropolitan area in the world.</p>
</div>

</body>
</html> 

link -
---- 

The link tag defines a link between a document and an external resource.
The link tag used to link to extrenal style sheet:

<head>
 <link rel="stylesheet" type="text/css" href="theme.css">
</head>

Note : - href = Specifies the location of the linked document.
         rel  = Required.Specifies the relation between the current document and the linked document.
		 type = Specifies the media type of the linked document.


span -
----

The <span> tag is used to group inline-elements in a document.

The <span> tag provides no visual change by itself.

The <span> tag provides a way to add a hook to a part of a text or a part of a document.

<html>
<body>

<p>My mother has <span style="color:blue;font-weight:bold">blue</span> eyes and my father has <span style="color:darkolivegreen;font-weight:bold">dark green</span> eyes.</p>

</body>
</html>

footer-
-------

The <footer> tag defines a footer for a documnet or section.

<!DOCTYPE html>
<html>
<body>

<footer>
  <p>Posted by: Hege Refsnes</p>
  <p>Contact information: <a href="mailto:someone@example.com">someone@example.com</a>.</p>
</footer>

<p><strong>Note:</strong> The footer tag is not supported in Internet Explorer 8 and earlier versions.</p>

</body>
</html>
****************************************************************************************************************************************
****************************************************************************************************************************************
----------------------------------------------------------todo Application--------------------------------------------------------------
****************************************************************************************************************************************
****************************************************************************************************************************************

Strict Mode is new feature in ECMAScript5 that allows you to place a program , or a function , in "strict" operating context.
This context prevents ceratin action from being taken and throws more exception.

Strict mode helps out in a couple ways:

. It catches some common coding bloopers , throwing exception.
. It prevents , or throws errors , when relatively "unsafe" actions are taken.(such as gaining access to the global object).
. It disbales features that are confusing or poorly thought out.


Example :  'use strict';




$routeParams/$location in Angular JS
---------------------------


Sometimes we encounter a situation where we need parameters of a URL .This can be achieved basically in 2 ways.

1. Using $location Service
2. Using $routeParams service

1.$location service - It exposes the curent URL in the address bar so that it can be observed or manipulated.
  ----------------  - If path() method of $location is called without passsing any parameter to it,returns path of the current url.

				  
E.G:

var module = angular.module("myApp", ['ngRoute']);
module.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/route1/:param1/:param2', {
            templateUrl: 'route1.html',
            controller: 'RoutingController'
        })
        .when('/route2/:param1/:param2', {
            templateUrl: 'route2.html',
            controller: 'RoutingController'
        })
        .otherwise({
            redirectTo: '/route1/default-book/default-page'
        });
}]);


module.controller("RoutingController", function ($scope, $routeParams, $location) {
    // Using $routeParams
    $scope.param1 = $routeParams.param1;
    $scope.param2 = $routeParams.param2;
});


Note : But , this is not a good practice and perhaps an ugly way , since we have hardcoded the index in order to get the parametres.
	   But one benefit of $location service is that it can be used even when $routeProvider is not used.

2. $routeParams - It is a combination of $location's search() and path().
   ------------       We can get the route path using the path() method of the $location service whereas as search() method of $location service
                      returns an object of search part/query string of the url.
					  
					  
	E.G:

var module = angular.module("myApp", ['ngRoute']);
module.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when('/route1/:param1/:param2', {
            templateUrl: 'route1.html',
            controller: 'RoutingController'
        })
        .when('/route2/:param1/:param2', {
            templateUrl: 'route2.html',
            controller: 'RoutingController'
        })
        .otherwise({
            redirectTo: '/route1/default-book/default-page'
        });
}]);
module.controller("RoutingController", function ($scope, $routeParams, $location) {
    // Using $routeParams
    $scope.param1 = $routeParams.param1;
    $scope.param2 = $routeParams.param2;
});


Note : The $routeParam will only work when $routeProvider is used.	
				  
/***********************************************************************************************************************************************************************************************************************/


$http service
-------------
.The Angular JS http service make a request to server and returns a response.
.The $http service is used to send or receive data from the remote server using browser's XMLHttpRequest or JSONP.
.$http is a service as an object. It includes following shortcut methods.

. $http.get()  -- Perform Http GET request.
. $http.head() -- Perform Http HEAD request.
. $http.post() -- Perform Http POST request.
. $http.put()    -- Perform Http PUT request.
. $http.delete() -- Perform Http DELETE request.
. $http.jsonp() -- Perform Http JSONP request.
. $http.patch() -- Perform Http PATCH request.

Example: $http.get()
--------------------
/***************************
old Version:-

$http.get(url, data)
.success(data, status, headers, config)
.error(data, status, headers, config);

***************************/

$http.get(url,config)
     .then(
	 function success(response){
		 //scucess callback
	 },
	 function error(response){
		 
		 // failure callback
	 }
	 )

The response object has foloowing properties.

1. data - It can be either string or an object(inserted object).
2. status - HTTP status code.
3. headers - header information.
4. config - configuartion that was used to send the request.
5. status Text - response of HTTP status text

/**************************************/


CONCEPT          DESCRIPTION

TEMPLATE  	 -	HTML with additional markup  
DIRECTIVES   -	Extends the HTML with custom attributes and elements  
MODEL  		 -	The data shown to the user in the view and with which the user interacts  
SCOPE  		 -	A context where the model is stored so that controllers, directives and expressions can access it  
EXPRESSIONS  -	Executes JavaScript code inside brackets {{ }}.  
COMPILER  	 -	Parses the template and instantiates directives and expressions  
FILTER  	 -	Formats the value of an expression for display to the user  
VIEW  		 -	What the user sees (the DOM)  
DATA BINDING -  Sync data between the model and the view  
CONTROLLER   -	Maintains the application data and business logic  
MODULE  	 -	A container for different parts of an app including controllers, services, filters, directives which configure the Injector  
SERVICE  	 -	Reusable business logic, independent of views  
DEPENDENCY 	 -	Injection  Creates and wires objects and functions  
INJECTOR  	 -	Dependency injection container  
		  