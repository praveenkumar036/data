AngularJS Scopes
----------
 
 
 scope is a special JS object which plays the role of joining controllers with the views.
 scopes contain model data. In controllers , model data is accessed via $scope object.
 
 
 /*************************
SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE SCOPE 

-The scope is the binding part between the HTML (view) and the JavaScript (controller).
-The scope is available for both the view and controller.
-The scope is an object with available properties and methods.
-When adding properties to the $scope object in the controller, the view (HTML) get access to these properties.
-In the view, you do not use the prefix $scope , you just refer to a prototypename , like {{carname}}

Understadning the Scope
-----------------------

If we consider an AngularJS application to consist of:

.View, which is HTML.
.Model, which is the data avaiable for the current view.
.Controller ,which is the Javascript function that makes/changes/ removes / controls the data.

 Then the scope is the "model".
 The scope is JS object with properties and methods, which are available for both the view and controller.


Root Scope
----------

.All application have a $rootScope which is created on the HTML element that contains the ng-app directive.
. The rootScope is avaiable in the entire application.

Note :- If a variable has the same name in both the current scope and in the rootScope , the application use the one in Current scope.

**************************/
 
 <script>
 var mainApp = angular.module("mainApp");
 
 mainApp.controller("shapeController",function($scope){
	 
	 $scope.message = "In shape Controller";
	 $scope.type = "Shape";
	 
 })
 
 
 </script>

 
 
 
 
- Following are the important points to be considered in above example.

. $scope is passed as first argument to controller during its constructor definition.
. $scope.message and $scope.type are the models which are used in the HTML page.
. We can define functions as well in $scope.

Scope Inheritence
-----------------

Scope are controllers specific. If we defines nested controllers then the child controller will
inherit the scope of its parent controller.

<script>
var mainApp = angular.modeule("mainApp",[]);

    mainApp.controller("shapeController",function($scope){
	$scope.message = "In shape Controller";
	$scope.type = ""Shape;	
    });
	
    mainApp.controller("circleController",function($scope){
		
		$scope.message = "In circle controller";
	})
</script>

Following are two importants points to be considered in  above example.

. We have set values to modules in shapeController.
. We've overriden message in the child controller circleController , the overrriden message wil be used,.

Example:

AngularJS Service
-----------------

.AngularJS support service architecture. Services are javascript functions and are responsible to do sepcific tasks only.
.This makes them an individual entity which is maintainable and testable.
.Controllers, filters can call them as on requirement basis.Services are normally injected using dependency injection mechanism.
.Angulsr JS provides many inbulit services for example , $https:,$route,$window,$location . Each service is responsible for a
 specific task for e.g - $https: is used to make ajax call to get the server data .
                         $route: is used to define the routing information and so on.
.InBuilt services are always prefixed iwth $symbol.



There are two aways to create services.
---------------------------------------

.factory
.service


Using factory method
--------------------

Using factory method , we first define a factory and then assign method to it.

var mainApp = angular.module("mainApp",[]);
mainApp.factory("MathService",function(){
	
	var factory = {}; //JS object factory is created.
	
	// factory object is assigned with function multiply 
	factory.multiply = function(a,b){
		
		return a*b;
	}
	factory.add = function(a,b){
		
		return a+b;
	}
	
	return factory; // We need to return factory object.
	
})

//In JS we can assig function to a variable which is quite different from other Programming language.
//JS object contains both propery and function.

E.G


<html>

   <head>
      <title>Angular JS Services</title>
      <script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
   </head>
   
   <body>
      <h2>AngularJS Sample Application</h2>
      
      <div ng-app = "mainApp" ng-controller = "CalcController">
         <p>Enter a number: <input type = "number" ng-model = "number" /></p>
         <button ng-click = "multi()">X<sup>2</sup></button>
		 <br/><button ng-click = "add()">add</button>
         <p>Result: {{result}}</p>
      </div>
      
      <script>
         var mainApp = angular.module("mainApp", []);
         
         mainApp.factory('MathService', function() {
            var factory = {};
            
            factory.multiply = function(a, b) {
               return a * b
            }
			factory.addition = function(a,b){
		
			return a+b;
	     }
            return factory;
         });
         
         mainApp.controller('CalcController', function($scope, MathService) {

			$scope.multi = function(){	
			$scope.result = MathService.multiply($scope.number,$scope.number+1)
			
			};
			$scope.add = function(){	
			$scope.result = MathService.addition($scope.number,$scope.number-1)
			
			}
			
         });
      </script>
      
   </body>
</html>



Using Service Method
--------------------

var mainApp = angular.module("mainApp",[]);

mainApp.service('CalService',function(){
	
	this.square = function(a){ //this represent service object
		
		return a*a
	}
	
	
});


AngularJS Dependecy Injection
-----------------------------

Dependecy Injection is a software design pattern in which components are given their dependencies instead of hard coding them within the componenet.
This relieves a componenet from loacting the dependecy and makes dependencies configurable. This helps in making components reusable, maintainable 
and testable.

Angular JS provides a supreme Dependecy Injection mechanism. It provides following core components which can be injected into each other as dependecy.

. Value.
. factory.
. service.
. provider.
. constant.


Value Example:

value is simple JS object and it is used to pass values to controller during config phase.

//define a module
var mainApp = angular.module("mainApp", []);

// create a value object as "defaultInput" and pass it a data.

mainApp.Value("defaultInput",5);

//inject the value in the controller using its name "defaultInput"

mainApp.controller("CalcController", function($scope,CalcService,defaultInput){
	
	$scope.number = defaultInput;
	 $scope.result = CalcService.square($scope.number);
   
   $scope.square = function() {
      $scope.result = CalcService.square($scope.number);
   }
	
	
})

//factory and service Example are provided in begining of page.



Provider
--------

Provider is used by AngularJS internally to create services,factory etc.
Provider is a special factory method with a method get() which is used to return the value/service/factory.

EG:

//  define a module

var mainApp = angular.module("mainApp",[]);

//cretae a service using provider which defines a method square to return square of a number.

mainApp.config(function($provider)){
	
	$provider.provider('MathService',function(){
		
		this.get = function(){
			
			var factory = {};
			
			factory.multiply = function(a,b){
				
				return a*b;
			}
			
			return factory;
		};
		
	});
	
	
});


Constant
--------


constants are used to pass values at config pahse considering the fact that value cannot be used to be passed during config phase.

mainApp.constant("configparam","Constant Value");


ANGULARJS - CUSTOM DIRECTIVES
-----------------------------

Custom directives are used in AngularJS to extend the functionality of HTML.
Custom diretive are defined using "directive" functions.
AngularJS provides support to create custom directives for following type :


... Element directives - > Directive activates when a matcing element is encountered.
... Attribute - > Directive activates when a matching attribute is encountered.
... CSS - > Directive activates when a matching css style is encountered.
... Comment - > Directive activates when a matching comment is encountered.

  Understanding Custom Directive 
  ------------------------------
  
  <student name = "Praveen"></student><br/>
  <student name="Shumnaaap"<</student>
  
  Define custom directive to handle above custom html tags.
  ---------------------------------------------------------
  
  var mainApp = angular.module("mainApp",[]);
  
  //Create a directive , first parameter is the html element to be attached.
  //We are attaching student html tag.
  //This directive is acctivated as soon as any student element is encountered in Html.
  
  
  mainApp.directive('student',function(){
	  
	  //define directive object
	  
	  var directive = {};
	  
	  //restrict = E , signifies that directive is Element directive.
	  
	  directive.restrict ='E';
	  
	  //template replaces the complete element with its text.
	  
	  directive.templates = "Student :<b>{{student.name}}</b>, Roll No.:<b>{{student.rollno}}</b>";
	  
	  //scope is used to distinguish each student based on criteria.
	  
	  directive.scope={
		  
		  student : "=name";
	  }
	  // Compile is called during application initialization. AngularJS calls it once when html page is loaded.
	  
	  directive.compile = function(elemnts,attributes){
		  
		  elements.css("border","1px solid #ccccccc");
		  
	 // linkFunction is linked with each element with scope to get the element specific data.
	    
		     var linkFunction = function($scope,element,attribute){
		     	element.html("Student :<b>"+$scope.student.name+"</b>, Roll No:<b>"+$scope.student.rollno+"</b></br>");
		     	element.css("background-color", "#ff00ff");
		     }
	     return linkFunction;
	  }
	  
	 return directives;
  });
  

###Define controller to update the scope for directive . Here we are using name attribute's value as scope's child.


mainApp.controller('StudentController',function($scope){
	
	$scope.Praveen = {};
	$scope>Praveen.name = "Praveen Kumar";
	$scope.Praveen.rollno = 1;
	
	
	$scope.Soumya = {};
	$scope.Soumya.name = "Soumya Kumar";
	$Soumya.rollno = 2;
	
});



Example:


<html>
      <head>
	        <title>Angular JS Custom Directive</title>
			<script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
	  </head>
	  <body>
	        <h2>AngularJS Sample Application</h2>
			<div ng-app ="mainApp" ng-controller = "StudentController">
			  <student name = "Praveen"></student></br>
			  <student name = "Kumar"></student>
			</div>
	  </body>
	  
	  <script>
	  
	    var mainApp = angular.module("mainApp",[]);
		mainApp.directive('student',function(){
			var directive = {};
			directive.restrict = 'E';
			directive.template= "Student:<b>{{student.name}}</b>,Roll No:<b>{{student.rollNo}}</b>";
			  directive.scope={
			     	student: "=name"
			  }
			 directive.compile = function(element, attributes) {
               element.css("border", "1px solid #cccccc");
			
			     var linkFunction = function($scope,elemnet,attributes){
					element.html("Student: <b>"+$scope.student.name +"</b> , Roll No: <b>"+$scope.student.rollno+"</b><br/>");
					element.css("background-color", "#ff00ff");
				}
				return linkFunction; 
			 }
               return directive;
			 
		});
	  
	   mainApp.controller('StudentController', function($scope) {
            $scope.Praveen = {};
            $scope.Praveen.name = "Praveen Kumar";
            $scope.Praveen.rollno  = 1;

            $scope.Soumya = {};
            $scope.Soumya.name = "Soumya Kumar";
            $scope.Soumya.rollno  = 2;
         });
	  
	  
	  </script>
</html>

AngularJS Internationalization
------------------------------

AngularJS support inbuilt internationalization for three types of filter currency ,date and numbers.
We only need to incorporate corresponding JS according to locale for the country. By default it handles
the locale of the browser.For example, to use Danish locale, use following script.

<script src = "https://code.angularjs.org/1.2.5/i18n/angular-locale_da-dk.js"></script> 

Example

<html>
   
   <head>
      <title>Angular JS Forms</title>
   </head>
   
   <body>
      <h2>AngularJS Sample Application</h2>
      
      <div ng-app = "mainApp" ng-controller = "StudentController">
         {{fees | currency }}  <br/><br/>
         {{admissiondate | date }}  <br/><br/>
         {{rollno | number }}
      </div>
		
      <script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
      <script src = "https://code.angularjs.org/1.3.14/i18n/angular-locale_da-dk.js"></script>
      
      <script>
         var mainApp = angular.module("mainApp", []);
         
         mainApp.controller('StudentController', function($scope) {
            $scope.fees = 100;
            $scope.admissiondate  = new Date();
            $scope.rollno = 123.45;
         });
      </script>
      
   </body>
</html>

