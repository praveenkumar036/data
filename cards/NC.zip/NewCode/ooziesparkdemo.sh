kinit -kt  /home/kuprav/keytabs/kuprav.keytab kuprav//DataLakeProduction@CORP.OCWEN.COM
echo "Hello World"
  spark2-submit \
--conf spark.driver.extraClassPath=ojdbc7.jar \
--conf spark.executor.extraClassPath=ojdbc7.jar \
--jars /home/kuprav/jars/ojdbc7.jar \
--driver-memory 2g \
--executor-memory 40G \
--executor-cores 16 \
--master local \
--class RescapReport\
 /home/kuprav/spark_code/rescap_report_2.11-0.1.jar local
