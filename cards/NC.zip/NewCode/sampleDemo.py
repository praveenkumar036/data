def main():

    print("Executing Main Method")



if(__name__ == "__main__"):

    main()