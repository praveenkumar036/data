# dos2unix watcher.sh to conver file from DOS to unix
inputdir="/home/kuprav/input_dir/"
outputdir="/home/kuprav/output_dir/"
haddopinputdir="/user/kuprav/inputdir/"
echo $inputdir
for file in `ls /home/kuprav/input_dir`; do
[[ -f $inputdir$file ]] && echo ""$file exists""
#./ftp_put.sh remotedirectoy $file
#clean up by moving files to a sent directory
hdfs dfs -put $inputdir$file $haddopinputdir
mv  $inputdir$file  $outputdir$file
done
