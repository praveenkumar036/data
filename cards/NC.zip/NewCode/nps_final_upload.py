from pyspark.sql import SparkSession
import pandas as pd
from pyspark.sql.types import StructType
from pyspark import SparkContext

def main():

  spark = SparkSession.builder.appName("NPS HRD BDD Upload").master("local").getOrCreate()

  spark.sparkContext.setLogLevel("ERROR")

  excel =  pd.read_excel("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\npshrd\\resource\\NPS_Consolidated_Jan-Mar-2018.xlsx" ,sheetname= "Mar 2018",dtype={

    'Serial No.': str, 'Date.submitted': str, 'LoanNumber': str, 'Date.of.Contact': str,
    'Method.of.Contact': str, 'Employee.ID': str, 'State': str, 'Supervisor.ID': str,
    'Supervisor.Name': str, 'Location': str, 'Loan.Status': str, 'Survey.Score': str,
    'Survey.Comments': str
  })


  # allExcelSheet =



  sparkExcel = spark.createDataFrame(excel)


  sparkExcel.printSchema()

  sparkExcel.createOrReplaceTempView("nps_hrd_t")
  # spark.sql("""
  #
  #           select t.*,case when t.LoanNumber > 100 then 'It is Good Loan' else 'Bad Loan' end status from nps_hrd_t t where LoanNumber ='7100720288'
  #
  #           """).show()

  spark.sql("select * from nps_hrd_t where LoanNumber in('7100720288',20124830)").show(20,False)



  # spark.sql("select * from nps_hrd_t where LoanNumber ='7100720288'").foreach(print)

  # sparkExcel.write.mode("overwrite").format("csv").option("header",True).save("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\resource\\nps_pandas_output.csv")


  # sparkExcel.show()

  # print(excel.columns)
  #
  # print(excel.count())



  # csvDF = spark.read.option("header",True).option("inferSchema",True).option("mode", "DROPMALFORMED").csv("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\npshrd\\resource\\NPS_Upload_Apr_18.csv")

  # csvDF = spark.read.option("badRecordsPath", "C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\npshrd\\malformedRecords\\nps_hrd_malformed.txt").option("header",True).option("inferSchema",True).csv("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\npshrd\\resource\\NPS_Upload_Apr_18_1.csv")


  # csvDF.write.mode("overwrite").format("csv").option("header",True).save("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\resource\\nps_output.csv")

  # csvDF.printSchema()
  # csvDF.show()

  spark.stop()



if(__name__ == "__main__"):

    main()

