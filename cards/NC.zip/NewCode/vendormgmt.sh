. /home/kuprav/spark_code/vendormgmt.env $1
printf  "*************************************Job Started at ${TIMESTAMP}**********************************\n" >> ${LOG_DIR}${DT}.log 

#SPARK JOB

spark2-submit \
--deploy-mode cluster \
--master ${MASTER} \
--class VendorManagement \
${SRC_CODE_DIR}vendormanagment_2.11-0.1.jar ${MASTER} ${HDFS_INP_DIR}x_Basic_Invoice_Report_02192018_03092018.csv ${DB} >> ${LOG_DIR}${DT}.log 2>&1



printf  "\n*************************************Job End  at ${TIMESTAMP}**********************************\n" >> ${LOG_DIR}${DT}.log
