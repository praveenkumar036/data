DT=`date +%Y%m%d`

rm -R /home/kuprav/rescap/*.csv

hdfs dfs -get /tmp/rssgworkflow/part*       /home/kuprav/rescap/rssgworkflow 
hdfs dfs -get /tmp/loaninfo/part*           /home/kuprav/rescap/loaninfo
hdfs dfs -get /tmp/requestdb/part*          /home/kuprav/rescap/requestdb
hdfs dfs -get /tmp/actionhistoryDB/part*    /home/kuprav/rescap/actionhistoryDB

mv /home/kuprav/rescap/rssgworkflow/part* /home/kuprav/rescap/rssgworkflow.csv
mv /home/kuprav/rescap/loaninfo/part* /home/kuprav/rescap/loaninfo.csv
mv /home/kuprav/rescap/requestdb/part* /home/kuprav/rescap/requestdb.csv
mv /home/kuprav/rescap/actionhistoryDB/part* /home/kuprav/rescap/actionhistoryDB.csv



echo "
Hi RSSG Team,

   Please find attached the Rescap comments from IRM and ISS:
   1.	RSS_Workflow_Rpt: This sheet contains the list of active workflow from Stage 5 as of today.
   2.	LoanInfo_Rescap: This sheet contains all matched loans from active workflow to ISS system.
   3.	RequestDB_Rescap: This sheet contains all requests of documents that could be found on IRM system.
   4.	ActionHistory_Rescap: This sheet contains the action history for all requests pointed to in Sheet 3 from IRM system.

Thanks,
BIGDATA Team
 " | mailx -a "/home/kuprav/rescap/rssgworkflow.csv" -a "/home/kuprav/rescap/loaninfo.csv" -a "/home/kuprav/rescap/requestdb.csv" -a "/home/kuprav/rescap/actionhistoryDB.csv" -s "RESCAP REPORT for $DT" BigDataTeam@ocwen.com