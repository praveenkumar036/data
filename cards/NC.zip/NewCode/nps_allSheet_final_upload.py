from pyspark.sql import SparkSession
import sys
import pandas as pd
from pyspark.sql.types import *
from pyspark import SparkContext

def main(args):

  spark = SparkSession.builder.appName("NPS HRD BDD Upload").master("local").getOrCreate()

  spark.sparkContext.setLogLevel("ERROR")

  schemaString = 'date_submitted,loan_number,date_of_contact,method_of_contact,employee_id,state,supervisor_id,supervisor_name,location,loan_status,survey_score,survey_comments,month'

  stringTypeFields = [StructField(fieldName, StringType(), True) for fieldName in schemaString.split(",")]

  schema = StructType(stringTypeFields)

#C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\npshrd\\resource\\NPS_2017_Update3_All.xlsx
  allExcelSheet = pd.ExcelFile(args ,
                               dtype={

                                 'date_submitted': str, 'loan_number': str, 'date_of_contact': str,
                                 'method_of_contact': str, 'employee_id': str,
                                 'state': str, 'supervisor_id': str, 'supervisor_name': str, 'location': str,
                                 'loan_status': str,
                                 'survey_score': str, 'survey_comments': str, 'month': str}
                               )

  excelRdd = spark.sparkContext.parallelize([])
  for sheet_name in allExcelSheet.book.sheets():
      if( sheet_name.visibility == 0):  # Read Only visible sheets
         excel = pd.read_excel(
             args,

         sheetname=sheet_name.name, dtype={

        'date_submitted': str, 'loan_number': str, 'date_of_contact': str, 'method_of_contact': str, 'employee_id': str,
        'state': str, 'supervisor_id': str, 'supervisor_name': str, 'location': str, 'loan_status': str,
        'survey_score': str, 'survey_comments': str, 'month': str

                 # 'Serial No.': str, 'Date.submitted': str, 'LoanNumber': str, 'Date.of.Contact': str,
                 # 'Method.of.Contact': str, 'Employee.ID': str, 'State': str, 'Supervisor.ID': str,
                 # 'Supervisor.Name': str, 'Location': str, 'Loan.Status': str, 'Survey.Score': str,
                 # 'Survey.Comments': str





             }, parse_cols= [0,1,2,3,4,5,6,7,8,9,10,11,12]   # Number Of Column Need To parse
         )


         tmpRdd = spark.createDataFrame(excel).rdd
         excelRdd = excelRdd.union(tmpRdd)
         # print(sheet_name.name,"=", sheet_name.visibility)

  # excelRdd.foreach(print)



  excelDF = spark.createDataFrame(excelRdd,schema)
  # excelDF.show()

  excelDF.createOrReplaceTempView("nps_hrd")


  spark.sql(""" 
  
  select row_number() over(order by  1) sl_no,date_submitted,loan_number,date_of_contact,method_of_contact,employee_id,state,supervisor_id,supervisor_name,location,loan_status,survey_score,survey_comments 
  ,month, count(1) over(partition by month ) / count(1) over() month_factor,count(1) over(partition by state ) / count(1) over() state_factor,count(1) over(partition by location ) / count(1) over() location_factor
  
  from nps_hrd
  
  
  
  """).show()



  spark.stop()



if(__name__ == "__main__"):

    string = str(sys.argv[1])

    main(string)
