from pyspark.sql import SparkSession
import sys
"""

create external table default.nps_hrd (
sl_no  int,
date_submitted string ,
loan_number string ,
date_of_contact string ,
method_of_contact string ,
employee_id string ,
state string ,
supervisor_id string ,
supervisor_name string ,
location string ,
loan_status string ,
survey_score string ,
survey_comments string ,
month string ,
month_factor double ,
state_factor double ,
location_factor double )

stored as parquet TBLPROPERTIES ("parquet.compression"="SNAPPY");

 load data local inpath '/home/kuprav/data/part-00000-799044eb-6d93-4a88-9730-b357e32ab1e7-c000.snappy.parquet' into table default.nps_hrd;


"""

def main(args):

     spark = SparkSession.builder.appName("NPS Parquet Load").master("local").getOrCreate()


     pdf = spark.read.parquet(args)

     # pdf.printSchema()
     #
     # pdf.show()

     pdf.createOrReplaceTempView("nps_hrd_parquet")


     spark.sql(" insert into nps_hrd  select * from nps_hrd_parquet ").show()

     spark.stop()





if(__name__ == "__main__"):

   string = sys.argv[1]
   main(string)

