#  from pyspark.sql import SparkSession
#
#
# from pyspark import SparkConf,SparkContext
# def main():
#
#    sc = SparkContext.
#      spark = SparkSession.builder.appName("Sample").master("local").getOrCreate()
#
#     srdd =  spark.sparkContext.parallelize([1,2,3])
#
#
# if(__name__ == "__main__"):
#
#     main()


from pyspark import SparkContext



def main():
    sc = SparkContext( "local",  "Sample program")

    trdd = sc.parallelize([1,2,3])


    trdd.foreach(print)

    sc.stop()

    print("hello")



if(__name__ == "__main__"):

    main()


