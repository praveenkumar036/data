import java.io.File

import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import org.apache.spark.sql.functions.input_file_name
import org.apache.spark.sql.functions.lit



object VendorManagement {


  def main(args : Array[String]): Unit ={


    val spark = SparkSession.builder.appName("Vendor Management Report").master(args(0)).getOrCreate()

//    spark.sparkContext.setLogLevel("ERROR")
//file:///home//kuprav//source_file//x_Basic_Invoice_Report_02192018_03092018.csv
    val inDF = spark.read.option("header",true).option("inferSchema",true).csv(args(1))

//    val x= "C:\\Users\\kuprav\\Desktop\\x_Basic_Invoice_Report_02192018_03092018.csv"

//    val y = x.toString().split(File.separator+File.separator).last


    val csvDF = inDF.withColumn("BUSINESS_FILE_NAME",lit(args(1).toString().split(File.separator+File.separator).last))




//  csvDF.printSchema()
//    val transCsvRdd = csvRdd.map(x=> Row(x(0),x(1),x(2),x(3),x(4),x(5),x(6), x(7),x(8),x(9),x(10),x(11),x(12),x(13),x(14),x(15),x(16),x(17),x(18),x(19),x(20)))

    val fields =
      Array(StructField("BUSINESS_UNIT_NAME",StringType,     nullable = true),
      StructField("INVOICE_NUMBER"         ,StringType,      nullable = true),
      StructField("INVOICE_AMOUNT"         ,DoubleType,      nullable = true),
      StructField("INVOICE_AMOUNT_PAID"    ,DoubleType,      nullable = true),
      StructField("SUPPLIER_NUMBER"        ,IntegerType,     nullable = true),
      StructField("INVOICE_CREATION_DATE"  ,StringType,   nullable = true),
      StructField("INVOICE_CREATED_BY"     ,StringType,      nullable = true),
      StructField("INVOICE_DESCRIPTION"    ,StringType,      nullable = true),
      StructField("INVOICE_DATE"           ,StringType,   nullable = true),
      StructField("PAY_GROUP"              ,StringType,      nullable = true),
      StructField("PAYMENT_METHOD"         ,StringType,      nullable = true),
      StructField("INVOICE_RECEIVED_DATE"  ,StringType,   nullable = true),
      StructField("INVOICE_CURRENCY"       ,StringType,      nullable = true),
      StructField("IDENTIFYING_PO"         ,IntegerType,     nullable = true),
      StructField("CHECK_NUMBER"           ,IntegerType,     nullable = true),
      StructField("PAYMENT_DATE"           ,StringType,   nullable = true),
      StructField("VOID_DATE"              ,StringType,   nullable = true),
      StructField("APPROVAL_STATUS"        ,StringType,      nullable = true),
      StructField("ACCOUNTING_STATUS"      ,StringType,      nullable = true),
      StructField("VALIDATION_STATUS"      ,StringType,      nullable = true),
      StructField("SUPPLIER_OR_PARTY_NAME" ,StringType,      nullable = true),
        StructField("BUSINESS_FILE_NAME",StringType, nullable = false))


    val schema = StructType(fields)


    val newDF = spark.createDataFrame(csvDF.rdd,schema)

//    newDF.printSchema()
//    newDF.show()


    newDF.createOrReplaceTempView("DF_F_VENDOR_INVOICE")

   // spark.sql("desc DF_F_VENDOR_INVOICE").show()

  val fOut =   spark.sql(
      """
        SELECT
       |BUSINESS_UNIT_NAME     ,
       |INVOICE_NUMBER         ,
       |INVOICE_AMOUNT         ,
       |INVOICE_AMOUNT_PAID    ,
       |SUPPLIER_NUMBER        ,
       |from_unixtime(unix_timestamp(INVOICE_CREATION_DATE, 'MM/dd/yyyy HH:mm')) INVOICE_CREATION_DATE ,
       |INVOICE_CREATED_BY     ,
       |INVOICE_DESCRIPTION    ,
       |from_unixtime(unix_timestamp(INVOICE_DATE, 'MM/dd/yyyy')) INVOICE_DATE         ,
       |PAY_GROUP              ,
       |PAYMENT_METHOD         ,
       |from_unixtime(unix_timestamp(INVOICE_RECEIVED_DATE, 'MM/dd/yyyy')) INVOICE_RECEIVED_DATE  ,
       |INVOICE_CURRENCY       ,
       |IDENTIFYING_PO         ,
       |CHECK_NUMBER           ,
       |from_unixtime(unix_timestamp(PAYMENT_DATE, 'MM/dd/yyyy')) PAYMENT_DATE           ,
       |from_unixtime(unix_timestamp(VOID_DATE, 'MM/dd/yyyy')) VOID_DATE              ,
       |APPROVAL_STATUS        ,
       |ACCOUNTING_STATUS      ,
       |VALIDATION_STATUS      ,
       |SUPPLIER_OR_PARTY_NAME,
       |current_timestamp LASTEST_UPDATED,
       |BUSINESS_FILE_NAME
       |FROM
       |DF_F_VENDOR_INVOICE
      """.stripMargin)


    fOut.createOrReplaceTempView("FINAL_F_VENDOR_INVOICE")

//    spark.sql("""select * from  FINAL_F_VENDOR_INVOICE   """).show()




  val db = args(2)
    spark.sql(s"use $db")

    spark.sql(s"""  insert into $db.F_VENDOR_INVOICE select * from  FINAL_F_VENDOR_INVOICE   """)


//    fOut.printSchema()
//
//    fOut.show()


    spark.stop()



  }


}
