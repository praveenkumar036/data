from pyspark.sql import SparkSession
import sys

def dataTypeConversion(type):
    switcher = {

        "numeric": "int"
        , "varchar": "string"
        , "decimal": "decimal"
        , "bit": "boolean"
        , "int": "int"
        , "datetime": "timestamp"
        , "smallint": "smallint"
        , "bigint": "bigint"
        , "image": "binary"
        , "char": "string"
        , "ntext": "string"
        , "smalldatetime": "timestamp"
        , "uniqueidentifier": "string"
        , "nvarchar": "string"
        , "xml":"xml"
        , "text":"string"
    }

    return  switcher[type]

def main(inPath,outPath,delimeter,dbName):

 spark = SparkSession.builder.appName("Iss DDL").master("local").getOrCreate()

 spark.sparkContext.setLogLevel("ERROR")

 readRdd = spark.sparkContext.textFile(inPath) #("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\resource\\ISS_export.csv")

 firstRdd = readRdd.first()

 processRdd = readRdd.filter(lambda x: x != firstRdd)

 # issRdd = processRdd.map(lambda x: x.split("|")).map(lambda x:(x[1],x[2] + "  "+ dataTypeConversion(x[3]) + " , ")).reduceByKey(lambda x,y : x+y).map(lambda x: "create external table iss." + x[0] + " ( " +x[1] + ") stored as parquet TBLPROPERTIES (\"parquet.compression\"=\"SNAPPY\");").map(lambda x : x.replace(", ) stored as parquet",") stored as parquet"))
 issRdd = processRdd.map(lambda x: x.split(delimeter)).map(lambda x:(x[1],x[2] + "  "+ dataTypeConversion(x[3]) + " , ")).reduceByKey(lambda x,y : x+y).map(lambda x: "create external table"+dbName+"." + x[0] + " ( " +x[1] + ") stored as parquet TBLPROPERTIES (\"parquet.compression\"=\"SNAPPY\");").map(lambda x : x.replace(", ) stored as parquet",") stored as parquet"))


 issRdd.saveAsTextFile(outPath) #("C:\\Users\\kuprav\\PycharmProjects\\untitled\\src\\resource\\output_ISS_DDL.txt")
 # issRdd.foreach(print)


 spark.stop()


if( __name__ == "__main__"):

   inPath = str(sys.argv[1])
   outPath = str(sys.argv[2])
   delimeter = str(sys.argv[3])
   dbName = str(sys.argv[4])

   main(inPath,outPath,delimeter,dbName)

  # print(dataTypeConversion("numeric"))